# Simplified Chinese localization and language switching modified by namink, 2026-10-29.
# SPDX-License-Identifier: GPL-3.0-or-later
"""Step 199 (#106): Maya option windows of the new Skin / Constrain commands.

Titles, buttons, labels and factory values from Maya 2022's option windows.
Fields the kit can't honour
are listed (``missing``), never faked.
"""

from ..i18n import tr as _zh, enum_items as _zh_enum, native as _zh_native

import bpy
from mathutils import Vector

from .option_windows import F, Window

WORLD_UP = ("Scene up", "Vector", "None")


def _aim_like(op_name):
    def run(context, v):
        up = Vector(v["world_up_vector"])
        if v["world_up_type"] == "Vector" and (up.length < 1e-9 or (up.normalized() - Vector((0, 1, 0))).length > 1e-6):
            raise RuntimeError("The kit turns the up vector towards the scene up only: World up vector must be 0 1 0 "
                               "(Maya Y)")
        return getattr(bpy.ops.allset, op_name)(
            'EXEC_DEFAULT', weight=v["weight"], aim_vector=v["aim_vector"], up_vector=v["up_vector"],
            world_up_type=v["world_up_type"])
    return run


def _aim_fields():
    return [F("aim_vector", "Aim vector:", "vec3", (1.0, 0.0, 0.0), translation_context='MWK:operators/option_windows_199.py:32'),
            F("up_vector", "Up vector:", "vec3", (0.0, 1.0, 0.0), translation_context='MWK:operators/option_windows_199.py:33'),
            F("world_up_type", "World up type:", "enum", "Vector", items=WORLD_UP, translation_context='MWK:operators/option_windows_199.py:34'),
            F("world_up_vector", "World up vector:", "vec3", (0.0, 1.0, 0.0), translation_context='MWK:operators/option_windows_199.py:35'),
            F("weight", "Weight:", "float", 1.0, lo=0.0, hi=1.0, translation_context='MWK:operators/option_windows_199.py:36')]


_AIM_MISSING = ("World up type: Object up / Object rotation up", "World up object")

REMOVE_TYPES = (("point", "Point constraint"), ("orient", "Orient constraint"), ("aim", "Aim constraint"),
                ("scale", "Scale constraint"), ("parent", "Parent constraint"), ("geometry", "Geometry constraint"),
                ("normal", "Normal constraint"), ("tangent", "Tangent constraint"),
                ("pole_vector", "Pole vector constraint"))


def _run_remove(context, v):
    kw = {k: v[k] for k, _l in REMOVE_TYPES}
    return bpy.ops.allset.remove_constraint_target('EXEC_DEFAULT', remove_all=v["remove_all"], **kw)


def _run_axes(context, v):
    return bpy.ops.allset.modify_constraint_axes('EXEC_DEFAULT', x=v["x"], y=v["y"], z=v["z"],
                                                maintain_offset=v["maintain_offset"])


def _run_substitute(context, v):
    return bpy.ops.allset.substitute_geometry('EXEC_DEFAULT', reweight_distance=v["reweight_distance"],
                                             retain_old=v["retain_old"], disable_non_skin=v["disable_non_skin"])


WINDOWS = [
    # Normal Constraint Options (factory aim 1 0 0, up 0 1 0, world up Vector 0 1 0, weight 1)
    Window("normal_constraint", "Normal Constraint Options", "Add", ("allset.normal_constraint", {}), _aim_fields(),
           _aim_like("normal_constraint"), paths=("Constrain/Normal",), missing=_AIM_MISSING, translation_context='MWK:operators/option_windows_199.py:64'),
    Window("tangent_constraint", "Tangent Constraint Options", "Add", ("allset.tangent_constraint", {}),
           _aim_fields(), _aim_like("tangent_constraint"), paths=("Constrain/Tangent",), missing=_AIM_MISSING, translation_context='MWK:operators/option_windows_199.py:66'),
    # Remove Target Options: all targets, every type, Maintain offset off
    Window("remove_constraint_target", "Remove Target Options", "Remove", ("allset.remove_constraint_target", {}),
           [F("remove_all", "Constraint type:", "bool", True, text=_zh_native("All", 'MWK:operators/option_windows_199.py:70'), translation_context='MWK:operators/option_windows_199.py:70')]
           + [F(k, "", "bool", True, text=_zh_native(label, 'MWK:operators/option_windows_199.py:71'), translation_context='MWK:operators/option_windows_199.py:71') for k, label in REMOVE_TYPES],
           _run_remove, paths=("Constrain/Remove Target",),
           missing=("Point on poly constraint (the kit's is a Shrinkwrap = Geometry)", "Maintain offset"), translation_context='MWK:operators/option_windows_199.py:69'),
    # Modify Constrained Axis Options: X / Y / Z on, Maintain offset off
    Window("modify_constraint_axes", "Modify Constrained Axis Options", "Modify",
           ("allset.modify_constraint_axes", {}),
           [F("x", "Constrain:", "bool", True, text=_zh_native("X", 'MWK:operators/option_windows_199.py:77'), translation_context='MWK:operators/option_windows_199.py:77'), F("y", "", "bool", True, text=_zh_native("Y", 'MWK:operators/option_windows_199.py:77'), translation_context='MWK:operators/option_windows_199.py:77'),
            F("z", "", "bool", True, text=_zh_native("Z", 'MWK:operators/option_windows_199.py:78'), translation_context='MWK:operators/option_windows_199.py:78'), F("maintain_offset", "", "bool", False, text=_zh_native("Maintain offset", 'MWK:operators/option_windows_199.py:78'), translation_context='MWK:operators/option_windows_199.py:78')],
           _run_axes, paths=("Constrain/Modify Constrained Axis...",), translation_context='MWK:operators/option_windows_199.py:75'),
    # Substitute Geometry Options
    Window("substitute_geometry", "Substitute Geometry Options", "Substitute Geometry",
           ("allset.substitute_geometry", {}),
           [F("reweight_distance", "Re-weighting distance tolerance:", "float", 1.0, lo=0.0, hi=10.0, translation_context='MWK:operators/option_windows_199.py:83'),
            F("disable_non_skin", "", "bool", False, text=_zh_native("Disable non-skin deformers", 'MWK:operators/option_windows_199.py:84'), translation_context='MWK:operators/option_windows_199.py:84'),
            F("retain_old", "", "bool", False, text=_zh_native("Retain old geometry", 'MWK:operators/option_windows_199.py:85'), translation_context='MWK:operators/option_windows_199.py:85')],
           _run_substitute, paths=("Skin/Substitute Geometry",),
           missing=("Move new geometry to a layer", "Move old geometry to a layer"), translation_context='MWK:operators/option_windows_199.py:81'),
]
